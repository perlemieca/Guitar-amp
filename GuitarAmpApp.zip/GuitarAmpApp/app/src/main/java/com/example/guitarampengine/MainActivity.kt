package com.example.guitarampengine

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private var engineRunning = false
    private lateinit var startStopButton: MaterialButton
    private lateinit var statusText: TextView

    private val requestMicPermission =
        registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                toggleEngine()
            } else {
                Toast.makeText(
                    this,
                    "Il permesso microfono è necessario per usare l'ampli.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startStopButton = findViewById(R.id.startStopButton)
        statusText = findViewById(R.id.statusText)

        val gainSlider = findViewById<Slider>(R.id.gainSlider)
        val toneSlider = findViewById<Slider>(R.id.toneSlider)
        val volumeSlider = findViewById<Slider>(R.id.volumeSlider)

        // Valori iniziali coerenti col default nel motore C++ (gain 5/20 ≈ 0.21)
        gainSlider.value = 0.21f
        toneSlider.value = 0.5f
        volumeSlider.value = 0.8f

        gainSlider.addOnChangeListener { _, value, _ -> NativeLib.setGain(value) }
        toneSlider.addOnChangeListener { _, value, _ -> NativeLib.setTone(value) }
        volumeSlider.addOnChangeListener { _, value, _ -> NativeLib.setVolume(value) }

        startStopButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                toggleEngine()
            } else {
                requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun toggleEngine() {
        if (!engineRunning) {
            val ok = NativeLib.startEngine()
            if (ok) {
                engineRunning = true
                startStopButton.text = getString(R.string.stop)
                statusText.text = getString(R.string.status_running)
            } else {
                Toast.makeText(
                    this,
                    "Impossibile avviare il motore audio. Riprova o ricollega l'interfaccia audio.",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            NativeLib.stopEngine()
            engineRunning = false
            startStopButton.text = getString(R.string.start)
            statusText.text = getString(R.string.status_stopped)
        }
    }

    override fun onPause() {
        super.onPause()
        // Ferma il motore quando l'app va in background, per liberare
        // lo stream audio esclusivo e risparmiare batteria.
        if (engineRunning) {
            NativeLib.stopEngine()
            engineRunning = false
            startStopButton.text = getString(R.string.start)
            statusText.text = getString(R.string.status_stopped)
        }
    }
}
