# Guitar Amp Engine

App Android per simulazione ampli chitarra a bassa latenza, basata su
[Oboe](https://github.com/google/oboe) (motore audio nativo C++ di Google).

## Come ottenere l'APK — 2 passaggi, tutto da smartphone

### Passaggio 1 — Carica questo progetto su GitHub
1. Vai su [github.com](https://github.com) e crea un account gratuito se non ce l'hai già.
2. Crea un nuovo repository (pulsante **New repository**), dagli un nome
   qualsiasi (es. `guitar-amp-app`), e lascialo **pubblico**.
3. Nella pagina del repository appena creato, tocca **"uploading an existing file"**
   (o **Add file → Upload files**).
4. Carica il file **`GuitarAmpApp.zip`** che ti ho fornito.
   GitHub lo estrae automaticamente mantenendo la struttura delle cartelle.
5. Conferma il commit ("Commit changes").

### Passaggio 2 — Scarica l'APK già compilato
1. Appena carichi i file, GitHub avvia automaticamente la compilazione
   (vedi la scheda **Actions** del repository — richiede 3-6 minuti).
2. Quando il flusso è completato (segno di spunta verde ✅), vai nella
   scheda **Releases** del repository (sulla destra nella pagina principale,
   o `github.com/TUO-USERNAME/TUO-REPO/releases`).
3. Scarica il file **`app-debug.apk`** dalla release più recente.
4. Apri il file scaricato dal telefono: Android chiederà di abilitare
   "Installa app da sorgenti sconosciute" per il browser/gestore file la
   prima volta — è normale, conferma e installa.

Fatto: l'app è installata e pronta all'uso.

## Uso dell'app

1. Collega la chitarra al telefono. Per una latenza davvero bassa serve
   un'**interfaccia audio USB** (es. un semplice adattatore jack-USB con
   DAC, o un pedale/interfaccia come il tuo Sonicake usato in modalità USB
   audio) collegata via **cavo OTG**. Il microfono interno del telefono
   funziona ma introduce più rumore e non è pensato per segnale di
   strumento a livello di linea.
2. Apri l'app, concedi il permesso microfono quando richiesto.
3. Premi **Avvia**.
4. Regola **Gain** (quantità di distorsione), **Tone** (brillantezza) e
   **Volume** con gli slider, in tempo reale.
5. Premi **Ferma** per chiudere lo stream audio.

## Note tecniche e limiti onesti

- Il progetto compila con un `applicationId` di esempio
  (`com.example.guitarampengine`): va bene per uso personale, ma se in
  futuro vuoi pubblicarlo su Google Play dovrai cambiarlo e firmarlo con
  una keystore di release (l'APK generato qui è una build "debug", firmata
  con una chiave di debug automatica — installabile ma non pubblicabile
  sullo store).
- La latenza reale dipende moltissimo dal telefono e, soprattutto,
  dall'interfaccia audio usata. Su telefoni di fascia media/alta con
  interfaccia USB dedicata è tipicamente nell'ordine di 10-20ms (impercettibile
  suonando); con il solo microfono interno può essere più alta.
- L'algoritmo di simulazione ampli incluso è volutamente semplice
  (saturazione tipo tanh + filtro tone one-pole): suona "distorto/ampli",
  non è un modellatore raffinato come Neural Amp Modeler. È pensato come
  base solida e leggibile da cui partire — si presta bene a essere
  esteso (EQ multibanda, cabinet IR via convoluzione, compressore, ecc.).
- Ogni volta che fai push di nuove modifiche al repository, GitHub Actions
  ricompila automaticamente e pubblica una nuova release con un nuovo APK.
